def iniciar():
    return

def parar():
    return

def mover_pulso():
    return

def parar_eixo():
    return

def ajustar_pulso(delta):
    return

def iniciar_varredura(eixo):
    return

def parar_varredura():
    return

def executar_varredura():
    return